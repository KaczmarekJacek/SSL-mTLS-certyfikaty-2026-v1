# PKI i mTLS — Dokumentacja teoretyczna

> Kompletny przewodnik po infrastrukturze klucza publicznego, certyfikatach X.509 i wzajemnym uwierzytelnianiu TLS.

## Spis treści

1. [Hierarchia PKI](#hierarchia-pki)
2. [Relacje między certyfikatami](#relacje-między-certyfikatami)
3. [Łańcuch zaufania](#łańcuch-zaufania)
4. [Keystore vs Truststore](#keystore-vs-truststore)
5. [Jak działa mTLS](#jak-działa-mtls)
6. [Struktura certyfikatu X.509](#struktura-certyfikatu-x509)
7. [Formaty plików](#formaty-plików)
8. [Bezpieczeństwo i najlepsze praktyki](#bezpieczeństwo-i-najlepsze-praktyki)

---

## Hierarchia PKI

### Trzypoziomowa architektura

PKI (Public Key Infrastructure) to hierarchiczny system zarządzania certyfikatami cyfrowymi. Nasza implementacja używa klasycznej trzypoziomowej hierarchii:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              ROOT CA                                         │
│                         (Self-signed)                                        │
│                                                                              │
│   Rola: Korzeń zaufania — najwyższy poziom hierarchii                       │
│   Ważność: 20 lat                                                            │
│   Przechowywanie: Offline / HSM (w produkcji)                               │
│   Użycie: Tylko do podpisywania Intermediate CA                             │
└─────────────────────────────────┬───────────────────────────────────────────┘
                                  │
                                  │ PODPISUJE
                                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          INTERMEDIATE CA                                     │
│                                                                              │
│   Rola: Pośredni urząd certyfikacji                                         │
│   Ważność: 10 lat                                                            │
│   Przechowywanie: Bezpieczny serwer / HSM                                   │
│   Użycie: Podpisywanie certyfikatów końcowych (server, client)              │
│   Ograniczenie: pathlen:0 — może podpisywać TYLKO certyfikaty końcowe       │
└──────────┬──────────────────────┬──────────────────────┬────────────────────┘
           │                      │                      │
           │ PODPISUJE            │ PODPISUJE            │ PODPISUJE
           ▼                      ▼                      ▼
┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐
│     SERVER       │    │    CLIENT A      │    │    CLIENT B      │
│                  │    │                  │    │                  │
│ Rola: Tożsamość  │    │ Rola: Tożsamość  │    │ Rola: Tożsamość  │
│       serwera    │    │       klienta    │    │       klienta    │
│ Ważność: 1 rok   │    │ Ważność: 1 rok   │    │ Ważność: 1 rok   │
└──────────────────┘    └──────────────────┘    └──────────────────┘
```

### Dlaczego trzy poziomy?

| Poziom | Uzasadnienie |
|--------|--------------|
| **Root CA** | Izolacja — klucz Root CA może być przechowywany offline (air-gapped), używany tylko do podpisania Intermediate CA |
| **Intermediate CA** | Operacyjność — kompromitacja Intermediate CA nie wymaga wymiany Root CA; można mieć wiele Intermediate CA dla różnych środowisk |
| **End-entity** | Krótki cykl życia — certyfikaty końcowe są wymieniane często (co rok), bez wpływu na infrastrukturę CA |

---

## Relacje między certyfikatami

### Wspólny "rodzic" — klucz do wzajemnego zaufania

W scenariuszu mTLS z jednym serwerem i wieloma klientami, **wszystkie certyfikaty są podpisane przez to samo Intermediate CA**:

```
                    INTERMEDIATE CA
                    (wspólny rodzic)
                          │
        ┌─────────────────┼─────────────────┐
        │                 │                 │
        ▼                 ▼                 ▼
    server.crt      service-a.crt    service-b.crt
        │                 │                 │
        └─────────────────┴─────────────────┘
                          │
                    RODZEŃSTWO
              (wzajemnie sobie ufają,
               bo mają tego samego rodzica)
```

### Co to oznacza w praktyce?

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│   Serwer ma w TRUSTSTORE certyfikat Intermediate CA                         │
│                           │                                                  │
│                           ▼                                                  │
│   Service-A przychodzi z certyfikatem podpisanym przez Intermediate CA      │
│                           │                                                  │
│                           ▼                                                  │
│   Serwer: "Intermediate CA podpisał tego klienta,                           │
│            a ja ufam Intermediate CA → więc ufam temu klientowi"            │
│                                                                              │
│   To samo działa w drugą stronę — klient weryfikuje serwer.                 │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Matematyka podpisów cyfrowych

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     JAK DZIAŁA PODPIS CERTYFIKATU                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  1. Intermediate CA bierze dane certyfikatu klienta (CN, klucz publiczny,   │
│     daty ważności, rozszerzenia)                                            │
│                                                                              │
│  2. Oblicza hash tych danych (SHA-384)                                      │
│                                                                              │
│  3. Szyfruje hash KLUCZEM PRYWATNYM Intermediate CA                         │
│     └── To jest PODPIS                                                       │
│                                                                              │
│  4. Dołącza podpis do certyfikatu                                           │
│                                                                              │
│  WERYFIKACJA:                                                                │
│                                                                              │
│  1. Serwer odczytuje podpis z certyfikatu klienta                           │
│                                                                              │
│  2. Deszyfruje podpis KLUCZEM PUBLICZNYM Intermediate CA                    │
│     └── Klucz publiczny jest w certyfikacie Intermediate CA (w truststore)  │
│                                                                              │
│  3. Oblicza własny hash danych certyfikatu                                  │
│                                                                              │
│  4. Porównuje: odszyfrowany hash == obliczony hash?                         │
│     └── TAK = certyfikat jest autentyczny i niezmieniony                    │
│     └── NIE = certyfikat jest sfałszowany lub uszkodzony                    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Łańcuch zaufania

### Chain of Trust — weryfikacja krok po kroku

Gdy serwer otrzymuje certyfikat klienta, musi zweryfikować cały łańcuch:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    WERYFIKACJA CERTYFIKATU KLIENTA                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  KROK 1: Sprawdź certyfikat klienta                                         │
│  ─────────────────────────────────────                                       │
│     client.crt                                                               │
│     │                                                                        │
│     └─► Issuer: "CN=Intermediate CA, O=MyCompany"                           │
│         │                                                                    │
│         └─► Szukam certyfikatu tego wystawcy...                             │
│                                                                              │
│  KROK 2: Sprawdź certyfikat Intermediate CA                                 │
│  ───────────────────────────────────────────────                             │
│     intermediateCA.crt                                                       │
│     │                                                                        │
│     ├─► Czy podpis na client.crt jest prawidłowy? ✓                         │
│     │                                                                        │
│     └─► Issuer: "CN=Root CA, O=MyCompany"                                   │
│         │                                                                    │
│         └─► Szukam certyfikatu tego wystawcy...                             │
│                                                                              │
│  KROK 3: Sprawdź certyfikat Root CA                                         │
│  ─────────────────────────────────────                                       │
│     rootCA.crt                                                               │
│     │                                                                        │
│     ├─► Czy podpis na intermediateCA.crt jest prawidłowy? ✓                 │
│     │                                                                        │
│     └─► Issuer: "CN=Root CA" (self-signed)                                  │
│         │                                                                    │
│         └─► Czy Root CA jest w moim TRUSTSTORE? ✓                           │
│                                                                              │
│  WYNIK: Cały łańcuch zweryfikowany — certyfikat klienta jest zaufany        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Plik ca-chain.crt

Aby uprościć weryfikację, tworzymy plik `ca-chain.crt` zawierający cały łańcuch CA:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           ca-chain.crt                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ -----BEGIN CERTIFICATE-----                                          │   │
│   │ [Intermediate CA Certificate]                                        │   │
│   │ -----END CERTIFICATE-----                                            │   │
│   │                                                                      │   │
│   │ -----BEGIN CERTIFICATE-----                                          │   │
│   │ [Root CA Certificate]                                                │   │
│   │ -----END CERTIFICATE-----                                            │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│   Kolejność: od najbliższego do Root CA                                     │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Keystore vs Truststore

### Fundamentalna różnica

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│   KEYSTORE  = "Kim JA jestem"      (moja tożsamość)                         │
│                                                                              │
│   TRUSTSTORE = "Komu JA ufam"      (lista zaufanych)                        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Keystore — moja tożsamość

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              KEYSTORE                                        │
│                        (np. server-keystore.p12)                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   Zawiera:                                                                   │
│   ┌───────────────────────────────────────────────────────────────────┐     │
│   │                                                                    │     │
│   │   🔑 KLUCZ PRYWATNY (tajny!)                                      │     │
│   │      └── używany do:                                              │     │
│   │          • podpisywania danych (dowód tożsamości)                 │     │
│   │          • deszyfrowania danych zaszyfrowanych kluczem publicznym │     │
│   │                                                                    │     │
│   │   📜 CERTYFIKAT (publiczny)                                       │     │
│   │      └── "dowód osobisty" wysyłany drugiej stronie                │     │
│   │      └── zawiera klucz publiczny                                  │     │
│   │                                                                    │     │
│   │   📜 ŁAŃCUCH CA (publiczny)                                       │     │
│   │      └── intermediate + root (dowód, kto mnie "wydał")            │     │
│   │                                                                    │     │
│   └───────────────────────────────────────────────────────────────────┘     │
│                                                                              │
│   🔴 POUFNOŚĆ: WYSOKA — zawiera klucz prywatny!                             │
│                                                                              │
│   Analogia: DOWÓD OSOBISTY + KLUCZ DO DOMU                                  │
│   • Dowód pokazujesz innym (certyfikat)                                     │
│   • Klucz do domu trzymasz tylko dla siebie (klucz prywatny)                │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Truststore — komu ufam

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                             TRUSTSTORE                                       │
│                          (truststore.p12)                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   Zawiera:                                                                   │
│   ┌───────────────────────────────────────────────────────────────────┐     │
│   │                                                                    │     │
│   │   📜 CERTYFIKATY CA (tylko publiczne!)                            │     │
│   │      ├── Root CA certificate                                      │     │
│   │      └── Intermediate CA certificate                              │     │
│   │                                                                    │     │
│   │   ❌ BEZ KLUCZY PRYWATNYCH                                        │     │
│   │                                                                    │     │
│   └───────────────────────────────────────────────────────────────────┘     │
│                                                                              │
│   🟢 POUFNOŚĆ: NISKA — zawiera tylko publiczne certyfikaty                  │
│                                                                              │
│   Analogia: LISTA ZAUFANYCH URZĘDÓW                                         │
│   • "Ufam dokumentom wystawionym przez Urząd Stanu Cywilnego"               │
│   • "Ufam dokumentom wystawionym przez ten konkretny CA"                    │
│   • Nie potrzebujesz ich kluczy prywatnych — tylko wiesz, że im ufasz       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Porównanie

```
┌─────────────────────────┬─────────────────────────┬─────────────────────────┐
│                         │       KEYSTORE          │      TRUSTSTORE         │
├─────────────────────────┼─────────────────────────┼─────────────────────────┤
│ Zawiera                 │ Klucz prywatny +        │ Tylko certyfikaty       │
│                         │ certyfikat + łańcuch CA │ CA (publiczne)          │
├─────────────────────────┼─────────────────────────┼─────────────────────────┤
│ Odpowiada na pytanie    │ "Kim jestem?"           │ "Komu ufam?"            │
├─────────────────────────┼─────────────────────────┼─────────────────────────┤
│ Używany do              │ Przedstawienia się      │ Weryfikacji             │
│                         │ drugiej stronie         │ drugiej strony          │
├─────────────────────────┼─────────────────────────┼─────────────────────────┤
│ Poufność                │ 🔴 TAJNY                │ 🟢 Może być publiczny   │
│                         │ (zawiera klucz pryw.)   │ (tylko certyfikaty)     │
├─────────────────────────┼─────────────────────────┼─────────────────────────┤
│ Unikalność              │ Każda aplikacja         │ Może być współdzielony  │
│                         │ ma własny               │ (ten sam dla wszystkich)│
├─────────────────────────┼─────────────────────────┼─────────────────────────┤
│ W naszym projekcie      │ server-keystore.p12     │ truststore.p12          │
│                         │ client-X-keystore.p12   │ (jeden dla wszystkich)  │
└─────────────────────────┴─────────────────────────┴─────────────────────────┘
```

### Jak współpracują w połączeniu mTLS

```
┌──────────────────────────────────┐         ┌──────────────────────────────────┐
│            SERWER                │         │            KLIENT                │
├──────────────────────────────────┤         ├──────────────────────────────────┤
│                                  │         │                                  │
│  KEYSTORE (server-keystore.p12)  │         │  KEYSTORE (client-keystore.p12)  │
│  ┌────────────────────────────┐  │         │  ┌────────────────────────────┐  │
│  │ 🔑 server.key              │  │         │  │ 🔑 client.key              │  │
│  │ 📜 server.crt  ────────────┼──┼────────►│  │ 📜 client.crt  ────────────┼──┼────┐
│  └────────────────────────────┘  │  (1)    │  └────────────────────────────┘  │    │
│                                  │         │                                  │    │
│  TRUSTSTORE (truststore.p12)     │         │  TRUSTSTORE (truststore.p12)     │    │
│  ┌────────────────────────────┐  │         │  ┌────────────────────────────┐  │    │
│  │ 📜 CA chain ◄──────────────┼──┼─────────┼──│ 📜 CA chain                │  │    │
│  │    (weryfikuje klientów)   │  │  (2)    │  │    (weryfikuje serwer) ◄───┼──┼────┘
│  └────────────────────────────┘  │         │  └────────────────────────────┘  │
│                                  │         │                                  │
└──────────────────────────────────┘         └──────────────────────────────────┘

(1) Serwer wysyła swój certyfikat → Klient weryfikuje przez SWÓJ truststore
(2) Klient wysyła swój certyfikat → Serwer weryfikuje przez SWÓJ truststore
```

---

## Jak działa mTLS

### TLS vs mTLS

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              TLS (jednokierunkowy)                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   Klient ◄─────── Serwer przedstawia certyfikat ─────── Serwer              │
│                                                                              │
│   • Klient weryfikuje tożsamość serwera                                     │
│   • Serwer NIE weryfikuje tożsamości klienta                                │
│   • Typowe użycie: HTTPS do stron WWW                                       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                              mTLS (dwukierunkowy)                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   Klient ◄─────── Serwer przedstawia certyfikat ─────── Serwer              │
│   Klient ─────── Klient przedstawia certyfikat ───────► Serwer              │
│                                                                              │
│   • Klient weryfikuje tożsamość serwera                                     │
│   • Serwer weryfikuje tożsamość klienta                                     │
│   • Typowe użycie: Komunikacja między mikroserwisami, API                   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Przebieg handshake mTLS

```
┌──────────┐                                          ┌──────────┐
│  CLIENT  │                                          │  SERVER  │
└────┬─────┘                                          └────┬─────┘
     │                                                     │
     │  1. ClientHello                                     │
     │     - Supported TLS versions (1.2, 1.3)             │
     │     - Supported cipher suites                       │
     │     - Random bytes                                  │
     │ ─────────────────────────────────────────────────► │
     │                                                     │
     │  2. ServerHello                                     │
     │     - Selected TLS version (1.3)                    │
     │     - Selected cipher suite                         │
     │     - Random bytes                                  │
     │ ◄───────────────────────────────────────────────── │
     │                                                     │
     │  3. Server Certificate                              │
     │     - server.crt                                    │
     │     - intermediateCA.crt (łańcuch)                  │
     │ ◄───────────────────────────────────────────────── │
     │                                                     │
     │  4. CertificateRequest (to włącza mTLS!)            │
     │     - "Wyślij mi swój certyfikat"                   │
     │     - Lista akceptowanych CA                        │
     │ ◄───────────────────────────────────────────────── │
     │                                                     │
     │  ┌─────────────────────────────────────────────┐   │
     │  │ KLIENT WERYFIKUJE SERWER:                    │   │
     │  │ • Czy server.crt podpisany przez znane CA?  │   │
     │  │ • Czy certyfikat nie wygasł?                │   │
     │  │ • Czy CN/SAN pasuje do hostname?            │   │
     │  └─────────────────────────────────────────────┘   │
     │                                                     │
     │  5. Client Certificate (mTLS)                       │
     │     - client.crt                                    │
     │ ─────────────────────────────────────────────────► │
     │                                                     │
     │  6. CertificateVerify (mTLS)                        │
     │     - Podpis kluczem prywatnym klienta             │
     │     - Dowód posiadania klucza prywatnego           │
     │ ─────────────────────────────────────────────────► │
     │                                                     │
     │                    ┌─────────────────────────────────────────────┐
     │                    │ SERWER WERYFIKUJE KLIENTA:                  │
     │                    │ • Czy client.crt podpisany przez znane CA?  │
     │                    │ • Czy certyfikat nie wygasł?                │
     │                    │ • Czy podpis CertificateVerify jest OK?     │
     │                    └─────────────────────────────────────────────┘
     │                                                     │
     │  7. Key Exchange (ECDHE)                            │
     │     - Uzgodnienie kluczy sesyjnych                  │
     │ ◄──────────────────────────────────────────────── │
     │                                                     │
     │  8. Finished (encrypted)                            │
     │ ◄──────────────────────────────────────────────── │
     │                                                     │
     │  ═══════════════════════════════════════════════   │
     │         SZYFROWANA KOMUNIKACJA APLIKACYJNA          │
     │  ═══════════════════════════════════════════════   │
```

### Przepływ weryfikacji

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    KLIENT ŁĄCZY SIĘ Z SERWEREM                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  KROK 1: Serwer przedstawia się                                             │
│  ─────────────────────────────────                                          │
│                                                                              │
│    Serwer ──► "Oto mój certyfikat (z MOJEGO keystore)"                      │
│                                                                              │
│    Klient ──► Sprawdza w SWOIM truststore:                                  │
│               "Czy znam CA, który podpisał ten certyfikat?"                 │
│               ✓ Tak → OK, ufam serwerowi                                    │
│               ✗ Nie → ODRZUCAM połączenie                                   │
│                                                                              │
│  KROK 2: Klient przedstawia się (mTLS)                                      │
│  ─────────────────────────────────────                                       │
│                                                                              │
│    Klient ──► "Oto mój certyfikat (z MOJEGO keystore)"                      │
│                                                                              │
│    Serwer ──► Sprawdza w SWOIM truststore:                                  │
│               "Czy znam CA, który podpisał ten certyfikat?"                 │
│               ✓ Tak → OK, ufam klientowi                                    │
│               ✗ Nie → ODRZUCAM połączenie                                   │
│                                                                              │
│  KROK 3: Szyfrowana komunikacja                                             │
│  ──────────────────────────────────                                          │
│                                                                              │
│    Obie strony używają uzgodnionych KLUCZY SESYJNYCH                        │
│    do szyfrowania/deszyfrowania danych                                      │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Struktura certyfikatu X.509

### Główne pola certyfikatu

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         CERTYFIKAT X.509 v3                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Version:             3 (0x2)                                               │
│  Serial Number:       1000 (unikalny numer)                                 │
│                                                                              │
│  Signature Algorithm: sha384WithRSAEncryption                               │
│                                                                              │
│  Issuer:              CN=Intermediate CA, O=MyCompany, C=PL                 │
│                       (kto wystawił certyfikat)                             │
│                                                                              │
│  Validity:                                                                   │
│      Not Before:      Jan  1 00:00:00 2025 GMT                              │
│      Not After:       Jan  1 00:00:00 2026 GMT                              │
│                                                                              │
│  Subject:             CN=localhost, O=MyCompany, C=PL                       │
│                       (dla kogo jest certyfikat)                            │
│                                                                              │
│  Subject Public Key:  RSA 4096 bit                                          │
│                       (klucz publiczny właściciela)                         │
│                                                                              │
│  X509v3 Extensions:                                                          │
│      Basic Constraints: CA:FALSE                                            │
│      Key Usage: Digital Signature, Key Encipherment                         │
│      Extended Key Usage: TLS Web Server Authentication                      │
│      Subject Alternative Name:                                              │
│          DNS:localhost                                                      │
│          DNS:*.localhost                                                    │
│          IP:127.0.0.1                                                       │
│                                                                              │
│  Signature:           [podpis Intermediate CA]                              │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Rozszerzenia X.509 — różnice między typami certyfikatów

#### Root CA

```
X509v3 Basic Constraints: critical
    CA:TRUE
X509v3 Key Usage: critical
    Certificate Sign, CRL Sign
```

#### Intermediate CA

```
X509v3 Basic Constraints: critical
    CA:TRUE, pathlen:0
X509v3 Key Usage: critical
    Certificate Sign, CRL Sign
```

#### Server Certificate

```
X509v3 Basic Constraints:
    CA:FALSE
X509v3 Key Usage: critical
    Digital Signature, Key Encipherment
X509v3 Extended Key Usage:
    TLS Web Server Authentication
X509v3 Subject Alternative Name:
    DNS:localhost, IP:127.0.0.1
```

#### Client Certificate

```
X509v3 Basic Constraints:
    CA:FALSE
X509v3 Key Usage: critical
    Digital Signature, Key Encipherment, Non Repudiation
X509v3 Extended Key Usage:
    TLS Web Client Authentication
```

### Subject Alternative Name (SAN)

SAN określa dla jakich hostów/IP certyfikat jest ważny:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SUBJECT ALTERNATIVE NAME                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   DNS:localhost                     ← dokładne dopasowanie                  │
│   DNS:*.localhost                   ← wildcard dla subdomen                 │
│   DNS:*.default.svc.cluster.local   ← Kubernetes services                   │
│   IP:127.0.0.1                      ← adres IP                              │
│   IP:10.0.0.1                       ← wewnętrzny IP                         │
│                                                                              │
│   Klient sprawdza czy hostname/IP do którego się łączy                      │
│   pasuje do któregoś z wpisów SAN.                                          │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Formaty plików

### Porównanie formatów

| Format | Rozszerzenie | Kodowanie | Zawartość | Użycie |
|--------|--------------|-----------|-----------|--------|
| **PEM** | `.pem`, `.crt`, `.key` | Base64 (tekst) | Certyfikaty, klucze | Uniwersalne, Linux |
| **DER** | `.der`, `.cer` | Binary | Certyfikaty | Windows, Java (stare) |
| **PKCS12** | `.p12`, `.pfx` | Binary | Cert + klucz + łańcuch | Java, Windows |
| **JKS** | `.jks` | Binary | Cert + klucz | Java (przestarzałe) |

### Format PEM

```
-----BEGIN CERTIFICATE-----
MIIFazCCA1OgAwIBAgIUZ3Z3Z3Z3Z3Z3Z3Z3Z3Z3Z3Z3Z3UwDQYJKoZIhvcNAQEL
BQAwRTELMAkGA1UEBhMCUEwxEzARBgNVBAgMCk1hem93aWVja2llMSEwHwYDVQQK
... (Base64 encoded data) ...
-----END CERTIFICATE-----
```

### Format PKCS12 (preferowany dla Java)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           PKCS12 (.p12)                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   • Format binarny (nie tekstowy)                                           │
│   • Chroniony hasłem                                                         │
│   • Zawiera wszystko w jednym pliku:                                        │
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │  🔑 Private Key                                                      │   │
│   │  📜 Certificate                                                      │   │
│   │  📜 CA Chain (opcjonalnie)                                          │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│   Zalety:                                                                    │
│   • Jedno hasło do całego pliku                                             │
│   • Łatwa dystrybucja (jeden plik zamiast wielu)                            │
│   • Natywne wsparcie w Java KeyStore API                                    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Dlaczego PKCS12 zamiast JKS?

| Aspekt | JKS | PKCS12 |
|--------|-----|--------|
| Standard | Własnościowy (Sun/Oracle) | Otwarty (RFC 7292) |
| Interoperacyjność | Tylko Java | Java, .NET, OpenSSL, przeglądarki |
| Szyfrowanie | Słabsze (PBEWithMD5AndTripleDES) | Silniejsze (AES-256) |
| Status | Deprecated od Java 9 | Zalecany |

---

## Bezpieczeństwo i najlepsze praktyki

### Ochrona kluczy prywatnych

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    POZIOMY OCHRONY KLUCZY PRYWATNYCH                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  🔴 ROOT CA KEY — NAJWYŻSZA OCHRONA                                         │
│     • Przechowywanie offline (air-gapped)                                   │
│     • HSM (Hardware Security Module) w produkcji                            │
│     • Dostęp tylko dla wyznaczonych osób                                    │
│     • Użycie: tylko do podpisania Intermediate CA (raz na 10 lat)           │
│                                                                              │
│  🟠 INTERMEDIATE CA KEY — WYSOKA OCHRONA                                    │
│     • Bezpieczny serwer z ograniczonym dostępem                             │
│     • HSM zalecany w produkcji                                              │
│     • Audit logging wszystkich operacji                                     │
│     • Użycie: podpisywanie certyfikatów końcowych                           │
│                                                                              │
│  🟡 SERVER/CLIENT KEYS — STANDARDOWA OCHRONA                                │
│     • Szyfrowanie hasłem (PKCS12)                                           │
│     • Uprawnienia plików: 400 (tylko właściciel)                            │
│     • Secrets management (Vault, K8s Secrets)                               │
│     • Rotacja: co rok                                                       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Ważność certyfikatów — zalecenia

| Typ certyfikatu | Środowisko Dev | Środowisko Prod |
|-----------------|----------------|-----------------|
| Root CA | 20 lat | 20 lat |
| Intermediate CA | 10 lat | 10 lat |
| Server/Client | 1 rok | 90 dni |

### Checklist bezpieczeństwa

```
□ Klucze prywatne CA nigdy nie opuszczają bezpiecznego środowiska
□ Hasła do keystores są unikalne i silne (nie "changeit" w produkcji!)
□ Certyfikaty mają odpowiednie rozszerzenia (CA:FALSE dla end-entity)
□ SAN zawiera wszystkie wymagane hosty/IP
□ Rotacja certyfikatów przed wygaśnięciem
□ Monitoring dat wygaśnięcia
□ Backup kluczy CA (zaszyfrowany, offline)
□ Procedura revokacji (CRL/OCSP) dla kompromitacji
```

### Typowe błędy

| Błąd | Konsekwencja | Rozwiązanie |
|------|--------------|-------------|
| Ten sam klucz dla wielu certyfikatów | Kompromitacja jednego = kompromitacja wszystkich | Unikalny klucz dla każdego certyfikatu |
| Brak SAN | Błędy weryfikacji hostname | Zawsze dodawaj SAN |
| Za długa ważność cert. końcowych | Większe okno ataku | Max 1 rok (90 dni w produkcji) |
| Hardcoded hasła | Wyciek credentials | Secrets management |
| Brak pathlen w Intermediate CA | Możliwość tworzenia nieautoryzowanych CA | Zawsze `pathlen:0` |

---

## Analogie do świata realnego

### Hierarchia PKI = System dokumentów

```
                         URZĄD STANU CYWILNEGO
                            (Root CA)
                                │
                    wydaje akty urodzenia
                                │
                                ▼
                         SZPITAL MIEJSKI
                         (Intermediate CA)
                                │
              ┌─────────────────┼─────────────────┐
              │                 │                 │
              ▼                 ▼                 ▼
          Jan Kowalski     Anna Nowak       Piotr Wiśniewski
          (server)         (client-a)       (client-b)
          
Każdy z nich ma "akt urodzenia" (certyfikat) wystawiony przez
ten sam szpital, więc mogą się wzajemnie zweryfikować sprawdzając,
czy ich dokumenty pochodzą z tego samego, zaufanego źródła.
```

### Keystore i Truststore = Dokumenty osobiste

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│   KEYSTORE = Twój portfel                                                   │
│   ─────────────────────────                                                  │
│   • Dowód osobisty (certyfikat) — pokazujesz innym                          │
│   • Klucz do domu (klucz prywatny) — trzymasz dla siebie                    │
│                                                                              │
│   TRUSTSTORE = Lista zaufanych instytucji                                   │
│   ──────────────────────────────────────                                     │
│   • "Ufam dokumentom z Urzędu Stanu Cywilnego"                              │
│   • "Ufam dokumentom z Ambasady RP"                                         │
│   • Nie masz ich kluczy — tylko wiesz, że im ufasz                          │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Podsumowanie

### Kluczowe koncepcje

1. **PKI** to hierarchiczny system zaufania: Root CA → Intermediate CA → End-entity
2. **Keystore** zawiera twoją tożsamość (klucz prywatny + certyfikat)
3. **Truststore** zawiera listę CA, którym ufasz
4. **mTLS** wymaga wzajemnej weryfikacji — obie strony przedstawiają certyfikaty
5. **Łańcuch zaufania** weryfikowany jest od certyfikatu końcowego do Root CA
6. **PKCS12** jest preferowanym formatem dla aplikacji Java

### Przepływ zaufania w mTLS

```
Serwer przedstawia certyfikat ←───────────────────────────→ Klient przedstawia certyfikat
        │                                                            │
        ▼                                                            ▼
Klient weryfikuje przez                                   Serwer weryfikuje przez
    SWÓJ truststore                                           SWÓJ truststore
        │                                                            │
        ▼                                                            ▼
"Czy znam CA który                                       "Czy znam CA który
 podpisał serwer?"                                        podpisał klienta?"
        │                                                            │
        ▼                                                            ▼
      ✓ TAK                                                        ✓ TAK
        │                                                            │
        └──────────────────── ZAUFANE ────────────────────────────────┘
                                    │
                                    ▼
                        SZYFROWANA KOMUNIKACJA
```
